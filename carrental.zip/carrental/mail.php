<?php
// Set SMTP settings
ini_set("SMTP", "smtp.gmail.com");
ini_set("smtp_port", "587");
ini_set("sendmail_from", "jrjairu2003@gmail.com");

// Recipient
$to = "abdulkalimkalim83199@gmail.com";

// Sender
$from = "jrjairu2003@gmail.com";
$subject = "Test email";
$message = "This is a test email sent using SMTP in PHP.";

// Additional headers
$headers = "From: $from\r\n";
$headers .= "Reply-To: $from\r\n";
$headers .= "Return-Path: $from\r\n";
$headers .= "X-Mailer: PHP\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

// Enable STARTTLS
$additional_flags = "-f $from -Xtls";

// Send email
$mail_sent = mail($to, $subject, $message, $headers, $additional_flags);

if ($mail_sent) {
    echo "Email sent successfully.";
} else {
    echo "Email sending failed.";
}
?>