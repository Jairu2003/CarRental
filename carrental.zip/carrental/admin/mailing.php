<?php
require 'D:\Xamp\htdocs\carrental\vendor\autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database configuration
$dbhost = 'localhost'; // Change this to your database host
$dbname = 'carrental'; // Change this to your database name
$dbuser = 'root'; // Change this to your database username
$dbpass = ''; // Change this to your database password

try {
    // Establish a database connection
    $conn = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
    // Set PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully<br>"; // You can remove this line or use it for testing
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage() . "<br>";
}

// Function to send email
function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'jrjairu2003@gmail.com'; // Your Gmail address
        $mail->Password = 'wzgm rdtt kgei somi'; // Your Gmail password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->SMTPDebug = 2;

        //Recipients
        $mail->setFrom('jrjairu2003@gmail.com', 'Jayaram');
        $mail->addAddress($to); // Add a recipient

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        echo "Email sent successfully to $to<br>";
        return true;
    } catch (Exception $e) {
        echo "Error sending email: " . $mail->ErrorInfo . "<br>";
        return false;
    }
}

function checkBookingStatusAndSendEmails($conn) {
    // Fetch all bookings with status 1 or 2
    $query = "SELECT * FROM tblbooking WHERE Status IN (1, 2)";
    $stmt = $conn->query($query);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($bookings as $booking) {
        $status = $booking['Status'];
        $userEmail = $booking['userEmail'];

        // Prepare the email content based on the status
        if ($status == 1) {
            $subject = 'Order Confirmed';
            $message = 'Your order has been confirmed. Thank you for choosing us.';
        } elseif ($status == 2) {
            $subject = 'Order Cancelled';
            $message = 'Your order has been cancelled. We apologize for any inconvenience caused.';
        }

        // Send the email
        $result = sendEmail($userEmail, $subject, $message);
        if ($result) {
            echo "Email sent successfully to $userEmail<br>";
        } else {
            echo "Failed to send email to $userEmail<br>";
        }
    }
}




  

