<?php
// Enable error reporting
error_reporting(E_ALL);

// Start session
session_start();

// Include configuration file
include('includes/config.php');

// Check if user is logged in
if (empty($_SESSION['login'])) {
    header('Location: index.php');
    exit();
}

// Check if booking_id is set and not empty
if (isset($_GET['booking_id']) && !empty($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];

    // Get user's email
    $sender_email = $_SESSION['login'];

    // Construct cancellation message
    $message = "Cancellation request for VechileID: $booking_id";

    // Insert cancellation request into the contact query table
    $sql = "INSERT INTO tblcontactusquery (EmailId, Message) VALUES (:email, :message)";
    $query = $dbh->prepare($sql);

    // Bind parameters
    $query->bindParam(':email', $sender_email, PDO::PARAM_STR);
    $query->bindParam(':message', $message, PDO::PARAM_STR);

    // Execute query
    if ($query->execute()) {
        // Set success message
        $_SESSION['cancel_success'] = "Your cancellation request has been sent to the admin.";
    } else {
        // Set error message
        $_SESSION['cancel_error'] = "An error occurred while sending the cancellation request.";
    }

    // Delay before redirecting (2 seconds)
    sleep(2);

    // Redirect back to the booking page
    header('Location: /carrental/my-booking.php'); // Adjust the path based on the actual location
    exit();
} else {
    // If booking_id is not set or empty, redirect back to the booking page
    header('Location: /carrental/my-booking.php'); // Adjust the path based on the actual location
    exit();
}
?>
