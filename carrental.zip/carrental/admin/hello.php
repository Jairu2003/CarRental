<?php
set_include_path(get_include_path() . PATH_SEPARATOR . __DIR__ . '/vendor/phpmailer/phpmailer/src');

// Include Composer's autoloader
require_once __DIR__ . '/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Your Gmail username and password
$username = "jrjairu2003@gmail.com";
$password = "kqzl bopw hozm sjxm";

// Sender and recipient email addresses
$fromEmail = "jrjairu2003@gmail.com";
$toEmail = "dilwala5669@gmail.com";

try {
    // Create a PHPMailer instance
    $mail = new PHPMailer(true);

    //Server settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = $username;
    $mail->Password   = $password;
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    //Recipients
    $mail->setFrom($fromEmail);
    $mail->addAddress($toEmail);

    // Content
    $mail->isHTML(true);
    $mail->Subject = "Hello from PHPMailer";
    $mail->Body    = "Hello World";

    // Send the email
    $mail->send();

    echo "Email sent successfully!";
} catch (Exception $e) {
    echo "Error sending email: " . $e->getMessage();
}
?>