<?php

set_include_path(get_include_path() . PATH_SEPARATOR . __DIR__ . '/vendor/phpmailer/phpmailer/src');

// Include Composer's autoloader
require_once __DIR__ . '/vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();
error_reporting(0);
include('includes/config.php');

// Function to send email
function sendEmail($to, $subject, $message) {
    $mail = new PHPMailer(true); // Create a new PHPMailer instance

    try {
        // Server settings
        $mail->isSMTP(); // Send using SMTP
        $mail->Host       = 'smtp.gmail.com';  // Specify your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'jrjairu2003@gmail.com';  // SMTP username
        $mail->Password   = 'lrht jrtz hfwu qugi';      // SMTP password
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;                  // TCP port to connect to

        // Recipients
        $mail->setFrom('jrjairu2003@gmail.com', 'Mailer');
        $mail->addAddress($to); // Add a recipient

        // Content
        $mail->isHTML(true); // Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
        echo 'Email has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}

// Check if session exists
if (isset($_SESSION['alogin'])) {
    // Output session value
    echo "Session email address: " . $_SESSION['alogin'] . "<br>";
    var_dump(filter_var($_SESSION['alogin'], FILTER_VALIDATE_EMAIL));
}

if (strlen($_SESSION['alogin']) == 0) {
    header('location:index.php');
} else {
    if (isset($_REQUEST['eid'])) {
        $eid = intval($_GET['eid']);
        $status = "2";
        $sql = "UPDATE tblbooking SET Status=:status WHERE  id=:eid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':status', $status, PDO::PARAM_STR);
        $query->bindParam(':eid', $eid, PDO::PARAM_STR);
        $query->execute();

        // Get user email address
        $getUserEmailQuery = "SELECT userEmail FROM tblbooking WHERE id = :eid";
        $getUserEmailStmt = $dbh->prepare($getUserEmailQuery);
        $getUserEmailStmt->bindParam(':eid', $eid, PDO::PARAM_INT);
        $getUserEmailStmt->execute();
        $row = $getUserEmailStmt->fetch(PDO::FETCH_ASSOC);
        $userEmail = $row['userEmail'];

        // Set user email address in session
        $_SESSION['user_email'] = $userEmail;

        // Send cancel email
        $subject = "Booking Cancellation";
        $message = "Your booking with ID $eid has been cancelled.";
        sendEmail($userEmail, $subject, $message);
    }

    // Handle booking confirmation
    if (isset($_REQUEST['aeid'])) {
        $aeid = intval($_GET['aeid']);
        $status = 1;

        $sql = "UPDATE tblbooking SET Status=:status WHERE  id=:aeid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':status', $status, PDO::PARAM_STR);
        $query->bindParam(':aeid', $aeid, PDO::PARAM_STR);
        $query->execute();

        // Get user email address
        $getUserEmailQuery = "SELECT userEmail FROM tblbooking WHERE id = :aeid";
        $getUserEmailStmt = $dbh->prepare($getUserEmailQuery);
        $getUserEmailStmt->bindParam(':aeid', $aeid, PDO::PARAM_INT);
        $getUserEmailStmt->execute();
        $row = $getUserEmailStmt->fetch(PDO::FETCH_ASSOC);
        $userEmail = $row['userEmail'];

        // Set user email address in session
        $_SESSION['user_email'] = $userEmail;

        // Send confirm email
        $subject = "Booking Confirmation";
        $message = "Your booking with ID $aeid has been confirmed.";
        sendEmail($userEmail, $subject, $message);
    }
}
?>
