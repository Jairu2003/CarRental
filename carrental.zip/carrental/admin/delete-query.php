<?php
// Include the database configuration file
include('includes/config.php');

// Check if query ID is provided and not empty
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Get the query ID
    $que_id = $_GET['id'];

    // Prepare the delete query
    $sql = "DELETE FROM tblcontactusquery WHERE id = :que_id";
    $query = $dbh->prepare($sql);
    
    // Bind the parameter
    $query->bindParam(':que_id', $que_id, PDO::PARAM_INT);
    
    // Execute the query
    $query->execute();
    
    // Check if deletion was successful
    if($query->rowCount() > 0) {
        // If successful, redirect to manage query page
        header("Location: manage-conactusquery.php");
        exit();
    } else {
        // If deletion fails, show error message and redirect to manage query page
        echo "Failed to delete query.";
        header("Location: manage-conactusquery.php");
        exit();
    }
} else {
    // If query ID is not provided or empty, redirect to manage query page
    header("Location: manage-conactusquery.php");
    exit();
}
?>
